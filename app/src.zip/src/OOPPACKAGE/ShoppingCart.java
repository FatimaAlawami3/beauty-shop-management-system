package OOPPACKAGE;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ShoppingCart extends JFrame {

    public static double discountedAmount = 0;
    private JLabel jLabel1, jLabel2;
    private JTextField jTextField1;
    private JTextArea jTextArea1;
    private JButton jButton1, jButton2;
    private JPanel jPanel1;
    private Connection conn;

    public ShoppingCart() {
        initComponents();
        setTitle("Shopping Cart - View Purchases");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        // Initialize database connection
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/beauty", "root", "Shoug@12");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error connecting to the database: " + ex.getMessage());
        }
    }

    private void initComponents() {

        jPanel1 = new JPanel();
        jLabel1 = new JLabel();
        jLabel2 = new JLabel();
        jTextField1 = new JTextField();
        jButton1 = new JButton();
        jButton2 = new JButton();
        JScrollPane jScrollPane1 = new JScrollPane();
        jTextArea1 = new JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 204, 204));

        jLabel1.setFont(new java.awt.Font("Segoe Print", 1, 36));
        jLabel1.setText("Shopping Cart");

        jLabel2.setFont(new java.awt.Font("Segoe Print", 1, 24));
        jLabel2.setText("Total Amount:");

        jTextField1.setEditable(false);

        jButton1.setFont(new java.awt.Font("Segoe Print", 1, 18));
        jButton1.setText("View Purchases");
        jButton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Segoe Print", 1, 18));
        jButton2.setText("Proceed to Payment");
        jButton2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(288, 288, 288)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                .addGap(82, 82, 82)
                                                                .addComponent(jLabel1))
                                                        .addComponent(jButton1)
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                .addComponent(jLabel2)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 636, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(348, 348, 348)
                                                .addComponent(jButton2)))
                                .addContainerGap(291, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(55, 55, 55)
                                .addComponent(jLabel1)
                                .addGap(43, 43, 43)
                                .addComponent(jButton1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel2)
                                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton2)
                                .addContainerGap(31, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(44, 44, 44)
                                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            String value1 = login.user_enterd;
            String value2 = login.password_enterd;
            String sql = "SELECT * FROM cart inner join products on cart.ProductId=products.PNUMBER";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            int total = 0;

            StringBuilder purchases = new StringBuilder();
            String purchase = "";
            double totalAmount = 0;
            while (rs.next()) {
                String PNAME = rs.getString("PNAME");
                int PNUMBER = rs.getInt("PNUMBER");
                int priceproducts = rs.getInt("PRICE");
                total += priceproducts;
                String PINFO = rs.getString("PINFO");
                String PRICE = rs.getString("PRICE");
                String SHADE = rs.getString("SHADE");
                String SIZE = rs.getString("SIZE");
                purchase += "NAME: " + PNAME + "\tProduct Id: " + PNUMBER + "\tPRICE:" + PRICE + "\tSHADE:" + SHADE + "\tSIZE:" + SIZE + "\n";
//                purchases.append(itemName).append(": $").append(price).append("\n");
//                totalAmount += price;
            }
            purchase += "\nTotal Price: " + total;
            jTextField1.setText(String.valueOf(total));
//            jTextArea1.setText(purchases.toString());
            jTextArea1.setText(purchase);

            try {
                FileWriter myWriter = new FileWriter("receipt.txt");
//                JOptionPane.showMessageDialog(null, "Receipt Downloaded!");
                myWriter.write(purchase);
//                );
//            }

                myWriter.close();
                System.out.println("Successfully wrote to the file.");
                JOptionPane.showMessageDialog(this, "Downloaded Receipt!");
            } catch (IOException e) {
                System.out.println("An error occurred.");
                JOptionPane.showMessageDialog(this, "An error occurred!");
                e.printStackTrace();
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error fetching purchases: " + ex.getMessage());
        }
    }

    private void deleteCart() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/beauty", "root", "Shoug@12");
            String sql = "DELETE FROM cart";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            PreparedStatement pstmt1;
            pstmt1 = conn.prepareStatement("SET FOREIGN_KEY_CHECKS=0");
            pstmt1.executeUpdate();

            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
//                JOptionPane.showMessageDialog(this, "Car deleted successfully.");
            } else {
//                JOptionPane.showMessageDialog(this, "No product found with ID " + productId);
            }
            conn.close();

        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {

        double totalAmount = Double.parseDouble(jTextField1.getText());

        if (totalAmount > 100) {
            discountedAmount = totalAmount * 0.9; // Applying 10% discount
            JOptionPane.showMessageDialog(this, "You got a 10% discount!\nTotal amount after discount: $" + discountedAmount);
      

            String[] options = {"Cash", "Credit"};

            int selection = JOptionPane.showOptionDialog(null, "Choose payment method", "Select one:",
                    0, 3, null, options, options[0]);
            if (selection == 0) {
                JOptionPane.showMessageDialog(null, "You have selected cash payment. Thanks for the order!");
                deleteCart();
                category back = new category();
                back.setVisible(true);
                this.dispose();
            }
            if (selection == 1) {

                Payment back = new Payment();
                back.setVisible(true);
                this.dispose();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Total amount: $" + totalAmount);
        }

    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ShoppingCart().setVisible(true);
            }
        });
    }
}

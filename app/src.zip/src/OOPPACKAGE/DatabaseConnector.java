/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OOPPACKAGE;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnector {
     public static void main(String[] args) {
        // Database URL
        String url = "jdbc:mysql://localhost:3306/beauty";
        // Database credentials
        String username = "root";
        String password = "Shoug@12";

        Connection conn = null;

        try {
            // Registration JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(url, username, password);

            if (conn != null) {
                System.out.println("Connected successfully!");
            } else {
                System.out.println("Failed to connect to database!");
            }
        } catch (SQLException | ClassNotFoundException e) {
            // Handle errors
            e.printStackTrace();
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
